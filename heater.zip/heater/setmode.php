<?php
require_once "config.php";

$facticmode = $_GET["facticmode"];
$id = $_GET["id"];
$sql = "UPDATE `heater` SET `mode`= '".$facticmode."' WHERE id=".$id;


echo($sql);


$result = mysqli_query($link, $sql);

mysqli_close($link);



?>