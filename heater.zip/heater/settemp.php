<?php
require_once "config.php";

$temp = $_GET["temp"];
$id = $_GET["id"];
$sql = "UPDATE `heater` SET `temp`= '".$temp."' WHERE id=".$id;





$result = mysqli_query($link, $sql);

mysqli_close($link);



?>