<?php
require_once "config.php";

$temp = $_GET["realtemp"];
$id = $_GET["id"];
$sql = "UPDATE `heater` SET `realtemp`= '".$temp."' WHERE id=".$id;





$result = mysqli_query($link, $sql);

mysqli_close($link);



?>