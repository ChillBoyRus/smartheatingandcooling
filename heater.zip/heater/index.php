<?php
header('Content-Type: application/json');
require_once "config.php";

$id = $_GET["id"];
$sql = "SELECT * FROM heater WHERE id=".$id;
$result = mysqli_query($link, $sql);
mysqli_close($link);
$bones = array();

$row = mysqli_fetch_array($result);
$arr = array('temp' => $row["temp"], 'realtemp' => $row["realtemp"], 'facticmode' => $row["mode"]);



echo json_encode($arr,JSON_FORCE_OBJECT );

?>


