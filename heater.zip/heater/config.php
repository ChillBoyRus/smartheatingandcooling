<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'davideqc_heater');
define('DB_PASSWORD', 'root123!');
define('DB_NAME', 'davideqc_heater');

/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
$link->set_charset("utf8");
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>