package com.davidenko.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.github.shchurov.horizontalwheelview.HorizontalWheelView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    EditText edittext;
    TextView realtemp;
    CountDownTimer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        realtemp = findViewById(R.id.textView2);

        NumberPicker numberPicker = findViewById(R.id.wheelview);

numberPicker.setMaxValue(50);
numberPicker.setMinValue(20);
     numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
         @Override
         public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

             new JsonTaskSend().execute("http://davideqc.beget.tech/heater/settemp.php?id=1&temp="+newVal);
             Log.i("test", newVal+"");

         }
     });




        timer = new CountDownTimer(3000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                new JsonTask().execute("http://davideqc.beget.tech/heater/index.php?id=1");
            }

            @Override
            public void onFinish() {
                start();
            }
        }.start();


    }


    private class JsonTaskSetMode extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;



            BufferedReader reader = null;

            try {

                Log.i("Http", params[0]);
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();

                connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:221.0) Gecko/20100101 Firefox/31.0"); // add this line to your code
                connection.connect();
                int status = connection.getResponseCode();
                Log.i("status", status+"");
                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-)

                }
                connection.disconnect(); //мб проблемы будут
                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);


            try {



                JSONObject obj = new JSONObject(result);











            } catch (Throwable t) {
                Log.e("JSON", "Could not parse malformed JSON: \"" + result + "\"");
            }


        }
    }
    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;



            BufferedReader reader = null;

            try {

                Log.i("Http", params[0]);
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();

                connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:221.0) Gecko/20100101 Firefox/31.0"); // add this line to your code
                connection.connect();
                int status = connection.getResponseCode();
                Log.i("status", status+"");
                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-)

                }
                connection.disconnect(); //мб проблемы будут
                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);


            try {



                JSONObject obj = new JSONObject(result);

                realtemp.setText(obj.getString("realtemp"));
                Log.i("JSON", obj.getString("realtemp"));













            } catch (Throwable t) {
                Log.e("JSON", "Could not parse malformed JSON: \"" + result + "\"");
            }


        }
    }
    private class JsonTaskSend extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;



            BufferedReader reader = null;

            try {

                Log.i("Http", params[0]);
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();

                connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:221.0) Gecko/20100101 Firefox/31.0"); // add this line to your code
                connection.connect();
                int status = connection.getResponseCode();
                Log.i("status", status+"");
                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-)

                }
                connection.disconnect(); //мб проблемы будут
                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);


            try {







            } catch (Throwable t) {
                Log.e("JSON", "Could not parse malformed JSON: \"" + result + "\"");
            }


        }
    }



    public  void heat(View view){
        new JsonTask().execute("http://davideqc.beget.tech/heater/setmode.php?id=1&facticmode=1");
    }

    public  void chill(View view){
        new JsonTask().execute("http://davideqc.beget.tech/heater/setmode.php?id=1&facticmode=2");
    }

    public  void take(View view){
        new JsonTask().execute("http://davideqc.beget.tech/heater/setmode.php?id=1&facticmode=0");
    }
}